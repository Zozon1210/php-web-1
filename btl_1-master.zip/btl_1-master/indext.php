<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="css/styles.css">
  
</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top ">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>                        
          </button>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
          <ul class="nav navbar-nav">
            <li class="active"><a href="#"><span class="glyphicon glyphicon-home"> Home</span></a></li>
            <li><a href="#">Game Online</a></li>
            <li><a href="#">Game Offline </a></li>
            <li><a href="#">Game PC & Console</a></li>
            <li><a href="#">Cộng Đồng</a></li>
            <li><a href="#">Gift code</a></li>
          </ul>
          <ul class="nav navbar-nav navbar-right">
            <li><a href="login/login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
          </ul>
          <form class="navbar-form navbar-right" role="search">
            <div class="form-group input-group">
              <input type="text" class="form-control" placeholder="Tìm Kiếm...">
              <span class="input-group-btn">
                <button class="btn btn-default" type="button">
                  <span class="glyphicon glyphicon-search"></span>
                </button>
              </span>        
            </div>
           </form>
        </div>
      </div>
  </nav>

<div class="container-fluid ">    
  <div class="row content">
    <div class="container">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
            <li data-target="#myCarousel" data-slide-to="3"></li>
          </ol>
      
          <!-- Wrapper for slides -->
          <div class="carousel-inner">
            <div class="item active">
              <img src="images/NewBanner.07.jpg" alt="" style="width:100%" >
            </div>
      
            <div class="item">
              <img src="images/jXKe1t5.jpg" alt=""  style="width:100%">
            </div>
          
            <div class="item">
              <img src="images/kQMfsER.jpg" alt="" style="width:100%" >
            </div>
            <div class="item">
                <img src="images/themebuilder_fdzg_header.jpg" alt=""  style="width:100%">
              </div>
          </div>
      
          <!-- Left and right controls -->
          <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
            <!-- Indicators -->
            <div class="row ">
              <div class="col-md-8">
                  <div class="panel panel">
                      <div class="bg-primary panel-heading">
                        <h2 class="  panel-title" style="font-size:20px">Tin Mới</h2>
                      </div>
                      <div class=" panel-body">
                          <div class="row">
                              <div class="col-md-4">
                                <img src="images/tin2.PNG" alt="">
                              </div>
                              <div class="col-md-7">
                                <h4><a href="#">This event fires on tab show, but before the new tab has been shown.</a></h4>
                                <p>This event fires on tab show after a tab has been shown. 
                                  Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.</p>
                              </div>
                              <button type="button" class="btn btn-primary" > Xem Thêm </button>
                          </div>  

                          <div class="row">
                              <div class="col-md-4">
                                <img src="images/tin2.PNG" alt="">
                              </div>
                              <div class="col-md-7">
                                <h4><a href="#">This event fires on tab show, but before the new tab has been shown.</a></h4>
                                <p>This event fires on tab show after a tab has been shown. 
                                  Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.</p>
                              </div>
                              <button type="button" class="btn btn-primary" > Xem Thêm </button>
                          </div>  

                          <div class="row">
                              <div class="col-md-4">
                                <img src="images/tin2.PNG" alt="">
                              </div>
                              <div class="col-md-7">
                                <h4><a href="">This event fires on tab show, but before the new tab has been shown.</a></h4>
                                <p>This event fires on tab show after a tab has been shown. 
                                  Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.</p>
                              </div>
                              <button type="button" class="btn btn-primary" > Xem Thêm </button>
                          </div>  

                          <div class="row">
                              <div class="col-md-4">
                                <img src="images/tin2.PNG" alt="">
                              </div>
                              <div class="col-md-7">
                                <h4><a href="">This event fires on tab show, but before the new tab has been shown.</a></h4>
                                <p>This event fires on tab show after a tab has been shown. 
                                  Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.</p>
                              </div>
                              <button type="button" class="btn btn-primary" > Xem Thêm </button>
                          </div>  

                          <div class="row">
                              <div class="col-md-4">
                                <img src="images/tin2.PNG" alt="">
                              </div>
                              <div class="col-md-7">
                                <h4><a href="#"> event fires on tab show, but before the new tab has been shown.</a></h4>
                                <p>This event fires on tab show after a tab has been shown. 
                                  Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.</p>
                              </div>
                              <button type="button" class="btn btn-primary" > Xem Thêm </button>
                          </div> 
                          <ul class="pagination">
                              <li class="active"><a href="#">1</a></li>
                              <li ><a href="#">2</a></li>
                              <li><a href="#">3</a></li>
                              <li><a href="#">4</a></li>
                              <li><a href="#">5</a></li>
                            </ul> 
                      </div>
                    </div>
              </div>

              <div class="col-md-4">
                  <div class="panel panel">
                      <div class="bg-primary panel-heading">
                        <h3 class="  panel-title" style="font-size:20px">Tin Xem Nhiều</h3>
                      </div>
                      <div class="panel-body">
                        <ul>
                          <li>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>
                            <p><a>Nội dung</p></a>                          
                          </li>
                        </ul>
                      </div>
                    </div>
              </div>
              <div class="col-md-4">
                  <div class="panel panel">
                      <div class="bg-primary panel-heading">
                        <h3 class="  panel-title" style="font-size:20px">Tin Hot</h3>
                      </div>
                      <div class="panel-body">
                        <ul>
                          <li>
                            <p><a>Nội dung</p></a>
                            <p>Nội dung</p>
                            <p>Nội dung</p>
                            <p>Nội dung</p>
                            <p>Nội dung</p>
                            <p>Nội dung</p>
                          </li>
                        </ul>


                      </div>
                    </div>
              </div>              
            </div>
    </div>
</div>
  <footer class="container-fluid text-center">
      <ul class="nav navbar-nav" style="margin-left:300px; background: black">
          <li><a href="#">Game Online</a></li>
          <li><a href="#">Game Offline </a></li>
          <li><a href="#">Game PC & Console</a></li>
          <li><a href="#">Cộng Đồng</a></li>
          <li><a href="#">Gift code</a></li>
        </ul>
  </footer>
    
</div>

</div>


</body>
</html>
